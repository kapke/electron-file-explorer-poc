declare let WEBPACK_ENV: string;
declare let System: {
  import: Function
};

